/* 1. 사용자 (USERS) */
CREATE TABLE USERS (
    user_id      VARCHAR2(20)  NOT NULL,
    password     VARCHAR2(255) NOT NULL,
    /* password VARCHAR2(255)를 사용한 이유는
       비밀번호는 보안을 위해 해싱 처리되어야 하기에, 암호화된 문자열을 저장할 공간을 확보하고자 이렇게 사용했습니다. */
    user_name    VARCHAR2(10)  NOT NULL,
    phone        VARCHAR2(20)  NOT NULL,
    /* phone VARCHAR2(20)를 사용한 이유는
       전화번호를 숫자(INT)로 저장하면 010의 '0'이 삭제되어 연락 기능에 문제가 생기기에 문자열 타입을 사용했습니다. */
    user_type    VARCHAR2(10)  NOT NULL,
    
    CONSTRAINT pk_users PRIMARY KEY (user_id),
    CONSTRAINT chk_user_type CHECK (user_type IN ('고객', '기사'))
    /* user_type CHECK ('고객', '기사')를 사용한 이유는
       DB에서 엉뚱한 값이 들어오는 것을 막고자, 회원의 역할은 오직 '고객' 아니면 '기사'만 허용했습니다. */
);

/* 2. 차량 (VEHICLE) */
CREATE TABLE VEHICLE (
    car_num      VARCHAR2(20) NOT NULL,
    car_type     VARCHAR2(20) NOT NULL,
    /* car_type VARCHAR2(20)를 사용한 이유는
       차량 매칭은 '그랜저' 같은 모델명이 아닌, '카고', '윙바디' 등 짐을 싣는 형태를 기준으로 수행되기에 이렇게 사용했습니다. */
    max_weight   NUMBER       NOT NULL,
    driver_id    VARCHAR2(20) NOT NULL,
    
    CONSTRAINT pk_vehicle PRIMARY KEY (car_num),
    CONSTRAINT fk_vehicle_driver FOREIGN KEY (driver_id) REFERENCES USERS(user_id) ON DELETE CASCADE,
    
    CONSTRAINT chk_weight CHECK (max_weight > 0),
    CONSTRAINT chk_car_type CHECK (car_type IN ('카고', '윙바디', '탑차', '냉동탑차', '다마스', '라보', '기타'))
);

/* 3. 공간 상태 (SPACE_STATUS) - 1:1 최적화 */
CREATE TABLE SPACE_STATUS (
    car_num      VARCHAR2(20) NOT NULL,
    /* car_num을 PK로 사용한 이유는
       차량 1대당 상태는 무조건 1개만 존재해야 하기에, 차량번호를 PK와 FK로 동시에 설정하여 1:1 관계를 강제했습니다. */
    current_capa NUMBER       NOT NULL,
    return_dest  VARCHAR2(20) NOT NULL,
    update_time  DATE         NOT NULL,
    /* update_time DATE를 사용한 이유는
       실시간 매칭에 필요한 정보이기에, 오라클의 DATE 타입을 사용하여 시간(시,분,초)까지 정확하게 기록했습니다. */
    
    CONSTRAINT pk_space_status PRIMARY KEY (car_num),
    CONSTRAINT fk_space_car FOREIGN KEY (car_num) REFERENCES VEHICLE(car_num) ON DELETE CASCADE,
    
    CONSTRAINT chk_capa CHECK (current_capa BETWEEN 0 AND 100)
);

/* 4. 주문 (ORDER_SHEET) */
CREATE TABLE ORDER_SHEET (
    order_id      VARCHAR2(20) NOT NULL,
    user_id       VARCHAR2(20) NOT NULL,
    /* user_id를 사용한 이유는
       주문을 요청한 고객이 누구인지 식별하고, 주문 상태의 라이프사이클을 관리하고자 이렇게 사용했습니다. */
    origin        VARCHAR2(20) NOT NULL,
    dest          VARCHAR2(20) NOT NULL,
    cargo_info    VARCHAR2(20) NOT NULL,
    price         NUMBER       NOT NULL,
    pickup_time   DATE         NOT NULL,
    /* pickup_time을 사용한 이유는
       매칭 알고리즘이 고객이 원하는 상차 시간을 기준으로 배차를 수행해야 하기에 필수 입력값으로 사용했습니다. */
    status        VARCHAR2(10) DEFAULT '대기' NOT NULL,
    /* status를 주문 테이블에 둔 이유는:
       '대기' 상태는 배차가 되기 전부터 존재해야 하므로, 상태 관리의 일관성과 조회 성능을 위해 이 컬럼을 사용했습니다. */
    
    CONSTRAINT pk_order PRIMARY KEY (order_id),
    CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES USERS(user_id) ON DELETE CASCADE,
    
    CONSTRAINT chk_status CHECK (status IN ('대기', '배차', '완료'))
);

/* 5. 배차 및 매칭 (DISPATCH) */
CREATE TABLE DISPATCH (
    dispatch_id   VARCHAR2(20) NOT NULL,
    order_id      VARCHAR2(20) NOT NULL,
    driver_id     VARCHAR2(20) NOT NULL,
    /* driver_id를 사용한 이유는
       실제 운전자가 누구인지(정산 대상) 명확히 기록하고자 driver_id 컬럼을 사용했습니다. (FK는 USERS.user_id 참조) */
    car_num       VARCHAR2(20) NOT NULL,
    /* car_num을 추가한 이유는:
       초기에는 1인 1차량으로 설계했으나, 추후 법인 차량이나 차량 임대 상황이 발생했을 때 '운전한 사람(정산 대상)'과 '운행된 차량(위치 추적 대상)'이 다를 수 있다는 점을 고려했습니다.
       즉, 물류 회사의 CEO가 자기 이름으로 수백대의 차량을 가지고 운전기사를 시켜 일을 하게 할 수있기 때문에 1인 N차량으로 설계했습니다.
       데이터 무결성을 위해 실제 운전자(ID)와 사용된 차량(차량번호)을 모두 기록하여, 정산은 기사에게, 관제는 차량 기준으로 처리할 수 있도록 확장성 있게 설계했습니다. */
    matched_at    DATE         NOT NULL,
    arrival_time  DATE,
    /* arrival_time을 사용한 이유는:
       배차가 완료된 시각(실제 도착 시각)을 기록하여 운행 완료 증거로 사용하고자 이 컬럼을 사용했습니다.
       또한 다른값과달리 이값은 NULL을 허용하는데, 그이유는 기사가 화물을 내려주고 시간을 측정해야되는데
       아직 화물을 받지않았거나, 운송중일때는 시간을 측정할 필요가없이 비워두어야 하기때문에 NULL값을 허용했습니다.*/
       
       
    
    CONSTRAINT pk_dispatch PRIMARY KEY (dispatch_id),
    CONSTRAINT fk_dispatch_order FOREIGN KEY (order_id) REFERENCES ORDER_SHEET(order_id) ON DELETE CASCADE,
    /*  fk_dispatch_order를 사용했지만, 주문 테이블에도 상태가 있는 이유는
       이론적으로는 중복이지만, 조회 성능과 주문의 라이프사이클(대기→완료) 관리를 위해 주문 테이블의 상태 컬럼을 유지했습니다.
       조회성능부터 분석해보면 만약 주문 테이블에 '상태' 컬럼이 없으면, "대기 중인 주문만 보여줘" 라고 할 때마다 배차 테이블과 LEFT JOIN을 해서 배차 정보가 없는지 확인해야 합니다.
       데이터가 계속 쌓여서 엄청나게 느려지는 오류가 생깁니다 
       두번째로 주문의 라이프사이클 관리를 위해 매우 중요한데, 배차테이블의 존재만으로 배차상태의 모든내용을 표기할수없습니다
       배차 완료 ➡️ 운송 중 ➡️ 운송 완료 ➡️ 정산 완료 등 더 많은 상태가 존재합니다. 배차 테이블 유무만으로는 이 모든 상태를 표현할 수 없습니다.
       따라서 주문테이블에 상태 컬럼을 집어넣게되었습니다. 
       단, 상태를 배차테이블과 주문의 상태컬럼에서 관리하기때문에 데이터 불일치 위험이 있을수있습니다.
       데이터 불일치 위험은 트랜잭션(Transaction)을 사용하여 배차 INSERT 시 주문 상태를 UPDATE 하도록 구현하여 방지할 예정입니다.
       종합적으로는 상태컬럼은 주문의 생애주기를 가장 빠르게 파악하는 요약정보의 역할을 합니다 따라서 데이터 불일치라는 중복위험 ( 상태컬럼과 배차시스템의 정보)을 감수하더라도
       주문 테이블에 남겨두는것이 업무의 효율성이 높아지는 방법이기때문에 이 방법을 선택했습니다.
       이러한 실무의 효율성같은 부분은 제가 선제적으로 알고있던게아닌, 컬럼의 개수나 연결방식을 LLM한테 물어보고 실제 의견을 종합하여 이렇게 정리하게 되었습니다. */
    CONSTRAINT fk_dispatch_driver FOREIGN KEY (driver_id) REFERENCES USERS(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_dispatch_car FOREIGN KEY (car_num) REFERENCES VEHICLE(car_num) ON DELETE CASCADE
);
--추가적으로 주문번호, 배차번호에 Varchar2를 사용한 이유는 전화번호와 같이 앞에 0이 올수도 있기때문에 0이 삭제되는 부분을 고려하여 바꾸었고
--주문번호, 배차번호는 Formatted Key (포맷팅된 키) 방식을 사용하려고 합니다.
--날짜 + 순차적인 일련번호(Sequence)을 사용하는 방식인데 날짜 - 구분자(하이픈) - 해당날의 주문순서(트랜잭션)로 
--예시는 20251203-0003 이런식으로 사용할려고합니다 단, 장점은 추적이 용이하고, 시간 순서대로 정렬되기 때문에 관리하기가 편리합니다. 


-- 단 1. 단점은 충돌이 존재할수있습니다. 예를들어 2대의 컴퓨터가 동시에 주문을 받으면, 둘 다 그날의 최신 순번(0001)을 가져가서 동일한 주문번호를 생성할 위험이 있습니다
--      이 부분은 백엔드로 하나의 트랜잭션 처리시에는 다른 컴퓨터가 오지 못하게 막아라 라는 명령을 시키면됩니다
--      또한 DB에서도 막을수있는 방법이 있는데, 순번을 저장하는 전용 테이블을 만들고, 이 테이블에 접근할 때 다른 작업 금지 락을 걸어주는 방법이 있습니다.
--      이부분도 검색하여 찾아보았지만, 백엔드 형태의 디테일부분이고 과제 취지와 맞지않아 해결방법만 간단하게 처리하고 넘어가겠습니다.
--      전용 테이블 생성 > 순번 발행 로직 (트랜잭션 락) 입니다 특히 순번발행로직에서의 
--      FOR UPDATE는 "내가 이 데이터를 업데이트할 테니, 다른 누구도 내가 끝낼 때까지 이 데이터를 수정하거나 읽지 못하게 막아라"라고 데이터베이스에 명령하는 것입니다.
--      (FOR UPDATE는 백엔드 코드 내부의 SELECT 구문에 들어갑니다. )
--      이 락 덕분에 아무리 많은 서버가 동시에 주문을 넣어도, 순번 증가 작업은 한 서버씩 순차적으로 처리되어 ID 충돌이 발생하지 않습니다.

--2. 또한 INT형보다는 데이터 크기가 크다는것인데 충돌위험이 적고 모든 값들이 무결성을 가져야한다면, UUID보다는 이 날짜+시퀀스 조합이 괜찮은 조합입니다.

