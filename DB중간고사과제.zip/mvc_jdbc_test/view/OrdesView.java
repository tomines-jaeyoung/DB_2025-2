package mvc_jdbc_test.view;

public class OrdesView {
}
